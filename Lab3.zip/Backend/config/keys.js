module.exports = {
    // mongoURI: '', //yout mlab instance details
    // secret: '' secret key
}